import java.io.*;
import javax.net.ssl.*;
public class SslSv {
    public static void main(String[] args) {
        try {
            SSLServerSocketFactory sf = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
            SSLServerSocket ss = (SSLServerSocket) sf.createServerSocket(6017);
            SSLSocket socket = (SSLSocket) ss.accept();
            String str;
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while ((str=br.readLine()) != null) {
                System.out.println(str);
                System.out.flush();
            }  } catch (Exception e) {
            e.printStackTrace();
        }}}

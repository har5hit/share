import java.util.Properties;
import javax.crypto.*;
import javax.mail.*;
import javax.mail.internet.*;
import sun.misc.BASE64Encoder;
public class Prac5 {
    public static void main(String[] args) {
        Properties props = new Properties();
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "465");
        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("16ramesh20@gmail.com", "password");
            }}); try {
            String msg = "hello all!!!",cipherText, decryptedText;
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(128);
            SecretKey secretKey = keyGen.generateKey();
            Cipher aesCipher = Cipher.getInstance("AES");
            aesCipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] byteDataToEncrypt = msg.getBytes();
            byte[] byteCipherText = aesCipher.doFinal(byteDataToEncrypt);
            cipherText = new BASE64Encoder().encode(byteCipherText);
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("16ramesh20@gmail.com"));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse("someone23@gmail.com"));
            message.setSubject("Testing Mail....");
            message.setText(cipherText);
            Transport.send(message);
            System.out.println("Your mail has been sent!!!");
        } catch (Exception e) {
            System.out.println(e);
        }}}

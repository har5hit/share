import java.io.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
class vfKey {
    public static void main(String[] args) {
        try
        {BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter the public key filename:");
            String pub = br.readLine();
            System.out.println("Enter the Signature filename:");
            String sigfile = br.readLine();
            System.out.println("Enter the filename:");
            String f_name = br.readLine();
            FileInputStream keyfis = new FileInputStream("E:\\Key\\" + pub);
            byte[] encKey = new byte[keyfis.available()];
            keyfis.read(encKey);
            keyfis.close();
            X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(encKey);
            KeyFactory keyFactory = KeyFactory.getInstance("DSA");
            PublicKey pubKey = keyFactory.generatePublic(pubKeySpec);
            FileInputStream sigfis = new FileInputStream("E:\\Key\\" + sigfile);
            byte[] sigToVerify = new byte[sigfis.available()];
            sigfis.read(sigToVerify);
            sigfis.close();
            Signature sig = Signature.getInstance("SHA1withDSA");
            sig.initVerify(pubKey);
            FileInputStream datafis = new FileInputStream("E:\\Key\\" + f_name);
            BufferedInputStream bufin = new BufferedInputStream(datafis);
            byte[] buffer = new byte[1024];
            int len;
            while(bufin.available()!=0) {
                len = bufin.read(buffer);
                sig.update(buffer, 0, len);
            } bufin.close();
            boolean verifies = sig.verify(sigToVerify);
            System.out.println("Signature verifies:" +verifies);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLite_DB_Management extends SQLiteOpenHelper{

    public static final String DATABASE_NAME = "student.db";                                          //Database name
    public static final String TABLE = "student_data";                                                //Table name
    public static final String FNAME_COL = "FNAME";
    public static final String EMAIL_COL = "EMAIL";

    public SQLite_DB_Management(Context context){
        super(context, DATABASE_NAME,null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + "(FNAME TEXT,EMAIL TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
    public boolean insertData(String name, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(FNAME_COL, name);
        contentValues.put(EMAIL_COL,email);
        long result = db.insert(TABLE, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
}

import java.io.IOException;
import java.net.*;
public class P4Server {
    public static int counter = 0;
    public static void main(String[] args) {
        try {
            ServerSocket server;
            server = new ServerSocket(4444);
            System.out.println("Running.. .");
            while (true) {
                Server pm = new Server();
                Socket socket = server.accept();
                pm.counter++;
                new Thread(new Operations(socket, pm.counter)).start();}
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}


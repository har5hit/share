import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.*;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;
import java.io.*;
import java.net.*;

public class Task_Handler extends AsyncTask<Void, Void, Void> {
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
    ProgressDialog pDialog;
    int flag;
    String name, email, save_type;
    private Context context;
    public Task_Handler(Context cxt, String name, String email, String save_type) {
        context = cxt;
        pDialog = new ProgressDialog(context);
        this.name = name;
        this.email = email;
        this.save_type = save_type;
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Saving..");
        pDialog.setCancelable(false);
        pDialog.show();
    }
    @Override
    protected Void doInBackground(Void... params) {
        switch (save_type) {
            case "SQLite Storage":
                SQL_storage();
                break;
            case "Internal Storage":
                Int_Storage();
                break;
            case "External Storage":
                Ext_Storage();
                break;
            case "Shared Preferences":
                Shared_Preference();
                break;
            case "Network Connection":
                Network_Storage();
                break;
        }
        return null;
    }
    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        pDialog.dismiss();
        if (flag == 1)
            Toast.makeText(context, "Error", Toast.LENGTH_LONG).show();
        else {
            Toast.makeText(context, "Saved", Toast.LENGTH_LONG).show();
        }
    }
    void SQL_storage() {
        SQLite_DB_Management sql = new SQLite_DB_Management(context);
        sql.insertData(name, email);
    }
    void Int_Storage() {
        String fileName = "Internal_Storage";
        String content = name + "\t" + email;
        FileOutputStream outputStream;
        try {
            outputStream = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            outputStream.write(content.getBytes());
            outputStream.close();
        } catch (Exception e) {
            flag = 1;
            e.printStackTrace();}}
    void Ext_Storage() {
        String content = name + "\t" + email, file_name = "ext_file";
        File file;
        try {
            int permission = ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // We don't have permission so prompt the user
                ActivityCompat.requestPermissions((Activity) context, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
            }
            file = new File(Environment.getExternalStorageDirectory().getAbsoluteFile(), file_name);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(content.getBytes());
            fos.close();
        } catch (IOException e) {
            flag = 1;
            e.printStackTrace();}}
    void Shared_Preference(){
        SharedPreferences sharedPreferences = context.getSharedPreferences("shared_preference_file",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString("name",name);
        editor.putString("email", email);
        editor.apply();
        if(sharedPreferences.getString("name","").isEmpty() ){
            flag=1;
        }else{
            flag=0;
        }
    }
    void Network_Storage(){
        String network_storage="http://192.168.0.104/save.php";
        try {
            URL url=new URL(network_storage);
            HttpURLConnection httpURLConnection=(HttpURLConnection)url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream=httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter=new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
            String post_data= URLEncoder.encode("name", "UTF-8")+"="+URLEncoder.encode(name,"UTF-8")+"&"
                    +URLEncoder.encode("email", "UTF-8")+"="+URLEncoder.encode(email,"UTF-8");
            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream=httpURLConnection.getInputStream();
            BufferedReader bufferedReader=new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));

            String result="",line="";
            while ((line=bufferedReader.readLine())!=null){
                result+=line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            Log.e("RESULT:",""+result);
        }catch (Exception e){
            Log.e("ERROR:",""+e);
        }
    }
}

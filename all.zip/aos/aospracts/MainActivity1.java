package practical10.msc.practical9;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.view.View;
import android.widget.Button;

public class MainActivity1 extends Activity {
    Button pause_btn,stop_btn;
    int mNotificationId = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pause_btn=(Button) findViewById(R.id.pause);
        stop_btn=(Button) findViewById(R.id.stop);
        pause_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Empty.class);
                startActivity(intent);}});
        stop_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });}
    @Override
    public void onStart() {
        super.onStart();
        Display_Notification("onStart() method invoked");
    }
    @Override
    public void onPause() {
        super.onPause();
        Display_Notification("onPause() method invoked");
    }
    @Override
    public void onResume() {
        super.onResume();
        Display_Notification("onResume() method invoked");
    }
    @Override
    public void onStop() {
        super.onStop();
        Display_Notification("onStop() method invoked");
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        Display_Notification("onDestroy() method invoked");
    }
    void Display_Notification(String msg) {
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.notification_icon)
                        .setContentTitle("Android Activity")
                        .setContentText(msg);
        NotificationManager mNotifyMgr =(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        mNotifyMgr.notify(mNotificationId++, mBuilder.build());
    }
}

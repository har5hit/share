import java.util.Scanner;
public class Prime_number extends Thread {
    static int x;
    void prime(int n){
        for (int i = 2; i < n; i++) {
            int flag = 0;
            for (int j = 2; j < i; j++) {
                if (i%j==0) {
                    flag=1;
                }}if(flag==0){
                System.out.println(i);}}}
    public void run(){
        prime(x);
    }
    public static void main(String[] args) {
        Prime_number pm = new Prime_number();
        System.out.println("Enter no");
        Scanner sc = new Scanner(System.in);
        x = sc.nextInt();
        pm.start();
    }
}

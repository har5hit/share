import java.io.*;
import java.net.Socket;
import java.util.Scanner;
public class Client {
    public static void main(String[] args) {
        int range;
        PrintWriter out;
        BufferedReader incoming;
        Socket socket = null;
        Scanner in = new Scanner(System.in);
        try {
            socket = new Socket("127.0.0.1", 4444);
            System.out.println("connected..");
            out = new PrintWriter(socket.getOutputStream(), true);
            incoming = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String result = incoming.readLine();
            if (result.equals("505")) {
                System.out.println("Connection refused due to too much client");
                socket.close();
            } else {
                System.out.println(result);}}
        catch (Exception e) {
            System.out.println(e);
        }
    }
}

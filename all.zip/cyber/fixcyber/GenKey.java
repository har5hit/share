import java.io.*;
import java.security.*;
public class GenKey {
    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter the file name:");
        try {
            String f_name = br.readLine();
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("DSA");
            SecureRandom rdm = SecureRandom.getInstance("SHA1PRNG");
            kpg.initialize(1024, rdm);
            KeyPair pair = kpg.genKeyPair();
            PrivateKey pr = pair.getPrivate();
            PublicKey pub = pair.getPublic();
            Signature dsa = Signature.getInstance("SHA1withDSA");
            dsa.initSign(pr);
            FileInputStream fs = new FileInputStream("E:\\Key\\" + f_name);
            BufferedInputStream bufin = new BufferedInputStream(fs);
            byte[] buffer = new byte[1024];
            int len;
            while (bufin.available() != 0) {
                len = bufin.read(buffer);
                dsa.update(buffer, 0, len);
            }
            bufin.close();
            byte[] realSig = dsa.sign();
            FileOutputStream sigfos = new FileOutputStream("E:\\Key\\sig");
            sigfos.write(realSig);
            sigfos.close();
            byte[] key = pub.getEncoded();
            FileOutputStream keyfos = new FileOutputStream("E:\\Key\\pub");
            keyfos.write(key);
            keyfos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }}}

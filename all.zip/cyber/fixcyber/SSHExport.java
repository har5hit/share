import java.io.*;
import java.security.*;
import java.security.spec.DSAPrivateKeySpec;

public class SSHExport {
    public static void main(String[] args) {
        try
        {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("DSA");
            SecureRandom rnd = SecureRandom.getInstance("SHA1PRNG","SUN");
            kpg.initialize(1024,rnd);
            KeyPair kp = kpg.generateKeyPair();
            Class spec = Class.forName("java.security.spec.DSAPrivateKeySpec");
            KeyFactory kf = KeyFactory.getInstance("DSA");
            DSAPrivateKeySpec ks = (DSAPrivateKeySpec)kf.getKeySpec(kp.getPrivate(), spec);
            FileOutputStream fos = new FileOutputStream("ExportedKey.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(ks.getX());
            oos.writeObject(ks.getP());
            oos.writeObject(ks.getQ());
            oos.writeObject(ks.getG());
            System.out.println("Private Key Exported");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }}}

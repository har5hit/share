import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.security.spec.DSAPrivateKeySpec;
public class SSHImport {
    public static void main(String[] args) {
        try {
            FileInputStream fis = new FileInputStream("exportedKey.txt");
            ObjectInputStream ois = new ObjectInputStream(fis);
            DSAPrivateKeySpec ks = new DSAPrivateKeySpec((BigInteger) ois.readObject(), (BigInteger) ois.readObject(), (BigInteger) ois.readObject(), (BigInteger) ois.readObject());
            KeyFactory kf = KeyFactory.getInstance("DSA");
            PrivateKey pk = kf.generatePrivate(ks);
            System.out.println("Got private key.");
        } catch (FileNotFoundException e) {
            System.out.println("Key not found.");
        } catch (Exception e) {
            System.out.println("Key is corrupted.");
        }}}

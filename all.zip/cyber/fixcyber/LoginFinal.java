import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.crypto.*;
public class LoginFinal extends JFrame implements ActionListener{
    JLabel lblUser, lblPass;
    JTextField txtUser;
    JPasswordField txtPass;
    JButton btnSub, btnRes;
    Connection con;
    PreparedStatement pst;
    Container c;
    SecretKey key;
    Cipher cipher;
    LoginFinal()    {
        c = getContentPane();
        lblUser = new JLabel("Enter Username:");
        txtUser = new JTextField(15);
        lblPass = new JLabel("Enter Password:");
        txtPass = new JPasswordField(15);
        btnSub = new JButton("Submit");
        btnRes = new JButton("Reset");
        c.add(lblUser);
        c.add(txtUser);
        c.add(lblPass);
        c.add(txtPass);
        c.add(btnSub);
        c.add(btnRes);
        c.setLayout(new FlowLayout());
        setVisible(true);
        setSize(300,200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Login Encryption");
        btnSub.addActionListener(this);
        btnRes.addActionListener(this);
        try        {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:LoginDSN");
            System.out.println("Connected");
            cipher = Cipher.getInstance("DESede");
            key = KeyGenerator.getInstance("DESede").generateKey();
        }
        catch(Exception e)
        {e.printStackTrace(); }}
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==btnSub)  {
            try    {
                String username = txtUser.getText();
                String password = txtPass.getText();
                byte[] uname = encrypt(username);
                byte[] pass = encrypt(password);
                String query = "insert into Login values(?,?)";
                pst=con.prepareStatement(query);
                pst.setBytes(1, uname);
                pst.setBytes(2, pass);
                pst.executeUpdate();
                System.out.println("Data inserted");
                System.out.println("Username : " +uname);
                System.out.println("Password : " +pass);
            }
            catch(SQLException e)  {
                e.printStackTrace();
            } }
        if(ae.getSource()==btnRes)        {
            txtUser.setText("");
            txtPass.setText("");
        }}
    public byte[] encrypt(String data)    {
        byte[] encryptedString = null;
        try        {
            cipher.init(Cipher.ENCRYPT_MODE,key);
            encryptedString = cipher.doFinal(data.getBytes());
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return encryptedString;
    }
    public static void main(String[] arg)   {
        new LoginFinal();   }}

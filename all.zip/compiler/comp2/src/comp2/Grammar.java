/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp2;
import java.io.*;
/**
 *
 * @author rajesh
 */
public class Grammar {
public static void main(String arr[]) throws IOException {
int i, j, k;
char temp[] = new char[20];
char left[] = new char[20];
char tempn[] = new char[20];
char templt[] = new char[20];
char templnt[] = new char[20];
  char right;
int count = 0;  int cn = 0;  int clt = 0;  int clnt = 0;
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  String str[] = new String[20];
System.out.println(" Enter The Right linear grammar is,separated by-: S-aB");
System.out.println("Enter q to Quit");
for (i = 0; i <str.length; i++) {
str[i] = br.readLine();
if (str[i].equals("q"))
break;  }
System.out.println("The Right linear grammar is:");
for (i = 0; i <str.length; i++) {
if (str[i].equals("q"))
    break;
System.out.println(str[i]);
  }
System.out.println("terminals are:");
  try {
for (i = 0; i <str.length; i++) {
for (j = 2; j <str[i].length(); j++) {
if (str[i].charAt(j) >= 97 &&str[i].charAt(j) <= 122) {
      if (i == 0)
temp[count] = str[i].charAt(j);
      else {
       for (k = 0; k <= count; k++) {
if (str[i].charAt(j) == temp[k]) {
break;        }       }
       if (k > count) {
        count++;
temp[count] = str[i].charAt(j);}}}}}}
 catch (NullPointerException e) {}
  for (i = 0; i <= count; i++)
System.out.print(temp[i] + " ");
System.out.println("\nNon terminals are:");
  count = 0;
  try {
for (i = 0; i <str.length; i++) {
for (j = 2; j <str[i].length(); j++) {
if (str[i].charAt(j) >= 65 &&str[i].charAt(j) <= 90) {
      if (i == 0)
temp[count] = str[i].charAt(j);
      else {

       for (k = 0; k <= count; k++) {
if (str[i].charAt(j) == temp[k]) {
         break;}}
       if (k > count) {
        count++;
temp[count] = str[i].charAt(j);}}}}}} catch (NullPointerException e) {}
  for (i = 0; i <= count; i++) {
System.out.print(temp[i] + " ");
  }
System.out.println();
System.out.println("The Left linear Grammar is:");
for (i = 0; i <str.length; i++) {
int cr = 0;
if (str[i].equals("q"))
    break;
   //checking whether 1st & last element of productions r nonterminal.
if ((str[i].charAt(0) >= 65 &&
str[i].charAt(0) <= 90) && (str[i].charAt(str[i].length() - 1) >= 65 &&
str[i].charAt(str[i].length() - 1) <= 90)) {
if ((str[i].length() - 2) / 2 >= 1) //finding the length of terminals.
    {
for (j = 2; j <str[i].length(); j++) {
      //Storing the terminals @ nonterminal after the terminals.
left[cr] = str[i].charAt(j);
cr++;
     }
     //reversing the element of left[k].
for (k = 0; k < (str[i].length() - 2) / 2; k++) {

      //System.out.print(left[k]);
      right = left[k];
left[k] = left[((str[i].length() - 2) - 1) - k];
left[((str[i].length() - 2) - 1) - k] = right;
     }
     //displaying the left linear grammar in proper manner.
System.out.print(left[0] + "\'" + "-" + str[i].charAt(0) + "\'");
for (k = ((str[i].length() - 2) - 1); k >= 1; k--) {
System.out.print(left[k]);
     }
System.out.println();
    } else
System.out.println(str[i].charAt(str[i].length() - 1) + "\'" + "-" +
str[i].charAt(0) + "\'");
   } else {
System.out.print("Z" + "\'" + "-" + str[i].charAt(0) + "\'");
for (j = 2; j <str[i].length(); j++)
System.out.print(str[i].charAt(j));
System.out.println();}}}}


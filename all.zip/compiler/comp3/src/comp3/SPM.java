/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp3;
import java.io.*;
/**
 *
 * @author rajesh
 */
public class SPM {
int i, j, k, l;
int count = 0;
int ct = 0;
 String prod[] = new String[50];
char temp[] = new char[50];
 String tempt = "";
 String str[] = new String[20];
 String firstm[][] = new String[50][50];
 String lastm[][] = new String[50][50];
 String firstp[][] = new String[50][50];
 String lastp[][] = new String[50][50];
 String lasts[][] = new String[50][50];
 String lastt[][] = new String[50][50];
 String firsts[][] = new String[50][50];
 String equalm[][] = new String[50][50];
 String less[][] = new String[50][50];
 String greater[][] = new String[50][50];
 String simplepm[][] = new String[50][50];
public void getproduction() {
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  try {
System.out.println("Enter The Production");
System.out.println("Enter q to quit");
for (i = 0; i <prod.length; i++) {
prod[i] = br.readLine();
if (prod[i].equals("q"))
     break;
   }
System.out.println("Produstions are:");
for (i = 0; i <prod.length; i++) {
if (prod[i].equals("q"))
     break;
System.out.println(prod[i]);
   }
  } catch (IOException e) {}
  //listing set of all the terminals &nonterminals.
  try {
for (i = 0; i <prod.length; i++) {
for (j = 0; j < prod[i].length(); j++) {
if (prod[i].charAt(j) != '-' && prod[i].charAt(j) != 'q') {
temp[count] = prod[i].charAt(j);
      count++;}}}} catch (NullPointerException e) {}
  //Removing the repeatation
for (i = 0; i <temp.length; i++) {
for (j = i + 1; j <temp.length; j++) {
    if (temp[i] == temp[j]) {
     temp[i] = '-';}}}
for (i = 0; i <temp.length; i++) {
if (temp[i] != '\0' && temp[i] != '-') {
    tempt += temp[i];
ct++;}}
System.out.println(tempt);
 }
public void first() {

  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
firstm[i][j] = "";
lastm[i][j] = "";}}
  for (i = 0; i <ct; i++) {
firstm[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
firstm[0][j + 1] += tempt.substring(j, j + 1);
  }
  try {
for (i = 0; i <prod.length; i++) {
    for (j = 0; j <= ct; j++) {
     for (k = 0; k <= ct; k++) {
if (prod[i].substring(0, 1).equals(firstm[j + 1][0]) &&
prod[i].substring(2, 3).equals(firstm[0][k + 1])) {
firstm[j + 1][k + 1] += "1";}}}}} catch (NullPointerException e) {}
System.out.println("First matrix--------------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (firstm[i + 1][j + 1] == "")
firstm[i + 1][j + 1] += "0";
System.out.print(firstm[i][j] + "\t");
   }
System.out.println("\n");}}
public void last() {
  for (i = 0; i <ct; i++) {
lastm[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
lastm[0][j + 1] += tempt.substring(j, j + 1);
  }
  try {
for (i = 0; i <prod.length; i++) {
    for (j = 0; j <= ct; j++) {
     for (k = 0; k <= ct; k++) {
if (prod[i].substring(0, 1).equals(lastm[j + 1][0]) &&
prod[i].substring(prod[i].length() - 1).equals(lastm[0][k + 1])) {
lastm[j + 1][k + 1] += "1";}}}}} catch (NullPointerException e) {}
System.out.println("Last matrix----------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (lastm[i + 1][j + 1] == "")

lastm[i + 1][j + 1] += "0";
System.out.print(lastm[i][j] + "\t");
   }
System.out.println("\n");}}
public void firstplus() {
int temp;
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
firstp[i][j] = firstm[i][j];}}
  for (i = 1; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (firstp[j][i].equals("1")) {
     for (k = 1; k <= ct; k++) {
      temp = Integer.parseInt(firstp[j][k]) | Integer.parseInt(firstp[i][k]);
      if (temp == 1)
firstp[j][k] = "1";}}}}
System.out.println("First+ matrix-----------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (firstp[i + 1][j + 1] == "")
firstp[i + 1][j + 1] += "0";
System.out.print(firstp[i][j] + "\t");
   }
System.out.println("\n");}}

public void lastplus() {
int temp;
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
lastp[i][j] = lastm[i][j];}}
  for (i = 1; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (lastp[j][i].equals("1")) {
     for (k = 1; k <= ct; k++) {
      temp = Integer.parseInt(lastp[j][k]) | Integer.parseInt(lastp[i][k]);
      if (temp == 1)
lastp[j][k] = "1";}}}}
System.out.println("Last+ matrix-----------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (lastp[i + 1][j + 1] == "")
lastp[i + 1][j + 1] += "0";
System.out.print(lastp[i][j] + "\t");}
System.out.println("\n");}}
public void firststar() {
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
    if (j == i)
     firsts[i][j] = "";
    else
     firsts[i][j] = firstp[i][j];}}
  for (i = 1; i <= ct; i++) {
   j = i;
firsts[i + 1][j + 1] += "1";}
System.out.println("First* Matrix------------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (firsts[i][j].equals(""))
firsts[i + 1][j + 1] += "0";
System.out.print(firsts[i][j] + "\t");
   }
System.out.println("\n");}}
public void laststar() {
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
    if (j == i)
     lasts[i][j] = "";
    else
     lasts[i][j] = lastp[i][j];}}
  for (i = 1; i <= ct; i++) {
   j = i;
   lasts[i][j] += "1";
  }
System.out.println("Last* Matrix------------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (lasts[i][j].equals(""))
lasts[i + 1][j + 1] += "0";
System.out.print(lasts[i][j] + "\t");
   }
System.out.println("\n");}}
public void equal() {
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
equalm[i][j] = "";}}
  for (i = 0; i <ct; i++) {
equalm[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
equalm[0][j + 1] += tempt.substring(j, j + 1);
  }
  try {
for (i = 0; i <prod.length; i++) {
    try {
if ((prod[i].substring(2).length()) >= 2); {
      for (j = 0; j <= ct; j++) {
       for (k = 0; k <= ct; k++) {
for (l = 2; l <= prod[i].length() - 2; l++) {
if (prod[i].substring(l, l + 1).equals(firstm[j + 1][0]) &&
prod[i].substring(l + 1, l + 2).equals(firstm[0][k + 1]))
equalm[j + 1][k + 1] += "1";}}}}}catch (StringIndexOutOfBoundsException e) {}
}  } catch (NullPointerException e) {}
System.out.println("Equal matrix------------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (equalm[i + 1][j + 1] == "")
equalm[i + 1][j + 1] += "0";
System.out.print(equalm[i][j] + "\t");
   }
System.out.println("\n");}}
public void lessthan() {
int temp, tempm;
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
    less[i][j] = "";}}
  for (i = 0; i <ct; i++) {
less[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
less[0][j + 1] += tempt.substring(j, j + 1);
  }
  for (i = 1; i <= ct; i++) {
   for (j = 1; j <= ct; j++) {
tempm = 0;
    for (k = 1; k <= ct; k++) {
     temp = Integer.parseInt(equalm[i][k]) &Integer.parseInt(firstp[k][j]);
tempm = tempm | temp;
    }
    if (tempm == 1)
     less[i][j] += "1";}
System.out.println("Lessthan matrix---------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (less[i + 1][j + 1] == "")
less[i + 1][j + 1] += "0";
System.out.print(less[i][j] + "\t");
   }
System.out.println("\n");}}}
public void greaterthan() {
int temp, tempm;
  String temps[][] = new String[50][50];
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
    greater[i][j] = "";}}
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
    temps[i][j] = "";}}
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
lastt[i][j] = "";}}
  for (i = 0; i <ct; i++) {
lastt[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
lastt[0][j + 1] += tempt.substring(j, j + 1);
  }
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
lastt[i + 1][j + 1] += lastp[j + 1][i + 1];}}
  for (i = 0; i <ct; i++) {
greater[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
greater[0][j + 1] += tempt.substring(j, j + 1);
  }
  for (i = 0; i <ct; i++) {
temps[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
temps[0][j + 1] += tempt.substring(j, j + 1);
  }
  for (i = 1; i <= ct; i++) {
   for (j = 1; j <= ct; j++) {
tempm = 0;
    for (k = 1; k <= ct; k++) {
     temp = Integer.parseInt(lastt[i][k]) &Integer.parseInt(equalm[k][j]);
tempm = tempm | temp;
    }
    if (tempm == 1)
     temps[i][j] += "1";}}
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (temps[i + 1][j + 1] == "")
temps[i + 1][j + 1] += "0";}}
  for (i = 1; i <= ct; i++) {
   for (j = 1; j <= ct; j++) {
tempm = 0;
    for (k = 1; k <= ct; k++) {
     temp = Integer.parseInt(temps[i][k]) &Integer.parseInt(firsts[k][j]);
tempm = tempm | temp;
    }
    if (tempm == 1)
     greater[i][j] += "1";}}
System.out.println("Greaterthan matrix------------------------------------------------------------");
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (greater[i + 1][j + 1] == "")
greater[i + 1][j + 1] += "0";
System.out.print(greater[i][j] + "\t");
   }
System.out.println("\n");}}
public void spmmatrix() {
int flag = 0;
  for (i = 0; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
simplepm[i][j] = "";}}
  for (i = 0; i <ct; i++) {
simplepm[i + 1][0] += tempt.substring(i, i + 1);
  }
  for (j = 0; j <ct; j++) {
simplepm[0][j + 1] += tempt.substring(j, j + 1);
  }
  for (i = 1; i <= ct; i++) {
   for (j = 1; j <= ct; j++) {
if (equalm[i][j].equals("1"))
simplepm[i][j] += "=";
if (less[i][j].equals("1"))
simplepm[i][j] += "<";
if (greater[i][j].equals("1"))
simplepm[i][j] += ">";}}
  for (i = 1; i <= ct; i++) {
   for (j = 0; j <= ct; j++) {
if (simplepm[i][j].length() > 1)
     flag = 1;}}
  if (flag == 1) {
System.out.println("The given matrix is not Simple Precedence Matrix-------");
  } else {
System.out.println("Simple Precedence Matrix----------------------------------------------------");
   for (i = 0; i <= ct; i++) {
    for (j = 0; j <= ct; j++) {
System.out.print(simplepm[i][j] + "\t");
    }
System.out.println("\n");}}}
public static void main(String arr[]) {
  SPM s = new SPM();
s.getproduction();
s.first();
s.last();
s.firstplus();
s.lastplus();
s.firststar();
s.laststar();
s.equal();
s.lessthan();
s.greaterthan();
s.spmmatrix();
 }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp1;
import java.io.*;
/**
 *
 * @author rajesh
 */
public class Transition {
int i, j, k;
char temp[] = new char[15];
char tempn[] = new char[15];
int cn = 0, cnt = 0;
int ct = 0, ctt = 0;
 String str[] = new String[10];
 String transt[][];
 String tempt = "", tempnt = "";
public void record() {
  try {
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
System.out.println(" Enter The Production,separated by -: S-aB");
System.out.println("Enter q to Quit");
for (i = 0; i <str.length; i++) {
str[i] = br.readLine();
if (str[i].equals("q"))
     break;}
System.out.println("The Productions are:");
for (i = 0; i <str.length; i++) {
if (str[i].equals("q"))
     break;
System.out.println(str[i]);}}catch (IOException e) {}
System.out.println("The start symbol is:");
System.out.println(str[0].charAt(0));
System.out.println("terminals of Productions are:");
  try {
for (i = 0; i <str.length; i++) {
if (!str[i].equals("q")) {
if (str[i].charAt(2) >= 97 &&str[i].charAt(2) <= 122) {
temp[ct] = str[i].charAt(2);
ct++;}}}}catch (Exception e) {}
  for (i = 0; i <ct; i++) {
   for (j = i + 1; j <ct; j++) {
    if (temp[i] == temp[j]) {
     temp[j] = '-';}}}
  for (i = 0; i <ct; i++) {
if (temp[i] != '\0' && temp[i] != '-')
System.out.println(temp[i]);}
System.out.println();
System.out.println("Non terminals are:");
  try {
for (i = 0; i <str.length; i++) {
if (!str[i].equals("q")) {
for (j = 0; j <str[i].length(); j++) {
if (str[i].charAt(j) >= 65 &&str[i].charAt(j) <= 90) {
tempn[cn] = str[i].charAt(j);
cn++;}}}}}catch (Exception e) {}
  for (i = 0; i <cn; i++) {
   for (j = i + 1; j <cn; j++) {
    if (tempn[i] == tempn[j]) {
tempn[j] = '-';}}}
  for (i = 0; i <cn; i++) {
if (tempn[i] != '\0' &&tempn[i] != '-')
System.out.println(tempn[i]);}
System.out.println("Transitions are:");
  try {
for (i = 0; i <str.length; i++) {
for (j = 0; j <str[i].length(); j++) {
if (str[i].charAt(j) != '-' &&str[i].charAt(j) != 'q')
System.out.print(str[i].charAt(j) + " ");}
System.out.println();}}catch (Exception e) {}}
public void ndfa() {
int cndf;
transt = new String[cn][ct];
  //put all the non terminals into rows and terminals into columns.
  for (i = 0; i <= ct; i++) {
if (temp[i] != '\0' && temp[i] != '-') {
    tempt += temp[i];
ctt++;}}
System.out.println("term=" + ctt + tempt);
  for (i = 0; i <= cn; i++) {
if (tempn[i] != '\0' &&tempn[i] != '-') {
tempnt += tempn[i];
cnt++;}}
System.out.println("nonterm=" + cnt + tempnt);
  for (i = 0; i <cn; i++) {
   for (j = 0; j <ct; j++) {
transt[i][j] = "";}}
for (j = 0; j <Math.max(ctt, cnt); j++) {
   if (j + 1 <= ctt)
transt[0][j + 1] = tempt.substring(j, j + 1);
   else
transt[0][j + 1] = "";
   if (j + 1 <= cnt)
transt[j + 1][0] = tempnt.substring(j, j + 1);
   else
transt[j + 1][0] = "";}
  //checking each string with each row,each row with each column.
  try {
for (i = 0; i <str.length; i++) {
    for (j = 0; j <cnt; j++) {
     for (k = 0; k <ctt; k++) {
if (str[i].substring(0, 1).equals(transt[j + 1][0]) &&
str[i].substring(2, 3).equals(transt[0][k + 1])) {
transt[j + 1][k + 1] += str[i].substring(3, 4);
      } else       transt[j + 1][k + 1] += "";}}}} catch (NullPointerException e) {}
System.out.println("Transition table:"); //displaying Transition
  for (i = 0; i <= cnt; i++) {
   for (j = 0; j <= ctt; j++) {
System.out.print(transt[i][j] + "\t");
   }
System.out.println("\n");}}
public static void main(String arr[]) {
  Transition t = new Transition();t.record();  t.ndfa();}}


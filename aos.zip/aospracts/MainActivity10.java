import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import java.util.ArrayList;
import java.util.List;

public class MainActivity10 extends Activity {
    public EditText name, email;
    Spinner spinner;
    Button save_btn;
    String save_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = (EditText) findViewById(R.id.f_name);
        email = (EditText) findViewById(R.id.email_xml);
        save_btn = (Button) findViewById(R.id.save_btn);
        spinner = (Spinner) findViewById(R.id.spinner_xml);
        fill_spinner();
        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save_type = spinner.getSelectedItem().toString();
                new Task_Handler(MainActivity.this, name.getText().toString(), email.getText().toString(), save_type).execute();
            }
        });
    }

    public void fill_spinner() {
        List<String> list = new ArrayList<String>();
        list.add("SQLite Storage");
        list.add("Internal Storage");
        list.add("External Storage");
        list.add("Shared Preferences");
        list.add("Network Connection");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
    }
}

import java.io.*;
import java.net.*;
import java.util.Scanner;
public class P2Client {
    private static Socket s;
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        try{
            s=new Socket("127.0.0.1",6017);
            OutputStream o=s.getOutputStream();
            OutputStreamWriter os=new  OutputStreamWriter(o);
            BufferedWriter b=new BufferedWriter(os);
            System.out.println("Enter the text");
            String m=(sc.next())+"\n";
            b.write(m);
            b.flush();
            System.out.println("msg  sent to the server : "+ m);
            InputStream is=s.getInputStream();
            InputStreamReader ir=new InputStreamReader(is);
            BufferedReader br=new BufferedReader(ir);
            String mg= br.readLine();
            System.out.println("Message received from Server: "+mg);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        finally{
            try{ s.close();}
            catch(Exception e) {
                e.printStackTrace();}
        }
    }
}

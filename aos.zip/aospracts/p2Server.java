import java.io.*;
import java.net.*;
public class P2Server {
    private static Socket socket;
    public static void main(String args[]) {
        try {
            ServerSocket serverSocket = new ServerSocket(6017);
            System.out.println("Server started and listening to the port 6102");
            while (true) {
                socket = serverSocket.accept();
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                String msg = br.readLine();
                System.out.println("Message received from client is " + msg);
                String returnMessage = "";
                try {
                    int d = 0; int v = 0;
                    for (int i = 0; i < msg.length(); ++i) {
                        char k = msg.charAt(i);
                        if (Character.isDigit(k)) {
                            d++; }
                        if (k == 'a' || k == 'e' || k == 'i' || k == 'o' || k == 'u') {
                            v++;}}
                    returnMessage = " No.of characters=" + msg.length() + "; No.of vovels=" + v + " No. of digits= " + d + "\n";
                } catch (Exception e) {}
                OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream());
                BufferedWriter bw = new BufferedWriter(osw);
                bw.write(returnMessage);
                System.out.println("Message sent to the client is " + returnMessage);
                bw.flush();}}catch (Exception e) {
            e.printStackTrace();} finally {
            try {socket.close();
            } catch (Exception e) {}
        }
    }
}


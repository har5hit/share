package com.example.student.practical8;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
public class MainActivity extends Activity {
    ImageView image_area;
    ProgressDialog pDialog;
    Bitmap bitmap;
    String imageURL = "http://www.ruiacollege.edu/images/banner/welcome.jpg";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image_area = (ImageView) findViewById(R.id.image_xml);
        new download_image().execute();
    }
    public class download_image extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Downloading..");
            pDialog.setCancelable(false);
            pDialog.show();
        }
        @Override
        protected Void doInBackground(Void... params) {
            try {
                InputStream input = new java.net.URL(imageURL).openStream();
                bitmap = BitmapFactory.decodeStream(input);
            } catch (IOException e) {
                Log.e("Error: ", "" + e);
            }            return null;        }
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            image_area.setImageBitmap(bitmap); pDialog.dismiss();
        }
    }
}

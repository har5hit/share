import java.io.*;
import java.net.Socket;
public class P4Operation implements Runnable {
    Socket socket;
    PrintWriter out;
    BufferedReader in;
    int counter = 0;
    Server pm = new Server();
    public Operations(Socket socket, int counter) {
        this.socket = socket;
        this.counter = counter;
        System.out.println("Connection number: " + this.counter);
    }
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            if (this.counter > 3) {
                out.println("505");
                System.out.println("Request from " + socket.getInetAddress() + " declined");
            } else {
                System.out.println("Connection from: " + socket.getInetAddress());
                out.println("You are Client No " + counter);}}
        catch (IOException | NumberFormatException e) {
            System.out.println(e);
        }
    }
}

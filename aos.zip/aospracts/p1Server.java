import java.io.*;
import java.net.*;
import java.util.*;

public class P1Server {
    public static void main(String ar[]) {
        try {
            String day = null;
            String quote = null;
            Calendar c = Calendar.getInstance();
            Date dt = new Date();
            c.setTime(dt);
            int dow = c.get(Calendar.DAY_OF_WEEK);
            switch (dow) {
                case 1: day = "SUNDAY";quote = "Quote of SUNDAY";
                    break;
                case 2: day = "MONDAY"; quote = "Quote of MONDAY";
                    break;
                case 3: day = "TUESDAY";quote = "Quote of TUESDAY";
                    break;
                case 4: day = "WEDNESDAY";quote = "Quote of WEDNESDAY";
                    break;
                case 5: day = "THURSDAY";quote = "Quote of THURSDAY";
                    break;
                case 6: day = "FRIDAY";quote = "Quote of FRIDAY";
                    break;
                case 7: day = "SATURDAY"; quote = "Quote of SATURDAY";
                    break;
            }
            ServerSocket sk = new ServerSocket(6017);
            while (true) {
                Socket cl = sk.accept();
                PrintWriter p = new PrintWriter(cl.getOutputStream(), true);
                if (quote.length() <= 512) {
                    p.println(day + "\n" + quote);
                }
                else {
                    p.println("more than 512 char");}
                cl.close();   }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}


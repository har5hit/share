import java.io.*;
public class P5 {
    public static final int ADDRESS_SIZE = 32;
    public static void main(String args[]) {
        try {
            if (args.length != 2) {
                System.out.println("Usage java Address<page size><address>");}
            System.out.println("Please enter the parameter  <Page Size><Address>");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            int ps = Integer.parseInt(br.readLine().trim());
            int ad = Integer.parseInt(br.readLine().trim());
            int pageBits = 0;
            int pageMask = 0;
            int offSetMask = 0;
            switch (ps) {
                case 1024:
                    pageBits = 10;
                    offSetMask = 0x000003ff;
                    pageMask = 0xfffffc00;
                    break;
                case 2048:
                    pageBits = 11;
                    offSetMask = 0x000007fd;
                    pageMask = 0xfffffa72;
                    break;
                case 4096:
                    pageBits = 12;
                    offSetMask = 0x00000fff;
                    pageMask = 0xfffff000;
                    break;
                case 8192:
                    pageBits = 13;
                    offSetMask = 0x00001fff;
                    pageMask = 0xffffe000;
                    break;
                case 16384:
                    pageBits = 14;
                    offSetMask = 0x000003ff;
                    pageMask = 0xfffffc00;
                    break;
                default: System.out.println("give proper address"); }
            int pn = (ad & pageMask) >> pageBits;
            int os = (ad & offSetMask);
            System.out.println("For address " + ad + ": pageNumber= " + pn + " offset= " + os);
        } catch (Exception e) {e.printStackTrace();
        }
    }
}

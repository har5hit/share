import java.io.*;
import java.net.*;
public class P1Client {
    public static void main(String ar[]) {
        InputStream i = null;
        BufferedReader b = null;
        Socket s = null;
        try {  s = new Socket(InetAddress.getLocalHost(), 6017);
            i = s.getInputStream();
            b = new BufferedReader(new InputStreamReader(i));
            String l;
            while ((l = b.readLine()) != null) {
                System.out.println(l); }
        } catch (IOException e) {
            System.out.println(e);
        } finally {
            try {s.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
